﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace ComparingObjects
{
    class Person : IComparable<Person>
    {
        private string name;
        private int age;
        private string town;

        public Person(string[] personDetails)
        {
            this.name = personDetails[0];
            this.age = int.Parse(personDetails[1]);
            this.town = personDetails[2];
        }

        public int CompareTo([AllowNull] Person other)
        {
            int namesCompare = this.name.CompareTo(other.name);
            int ageCompare = this.age.CompareTo(other.age);
            int townCompare = this.town.CompareTo(other.town);

            if (namesCompare == 0 && ageCompare == 0 && townCompare == 0)
            {
                return 0;
            }

            return -1;
        }
    }
}
