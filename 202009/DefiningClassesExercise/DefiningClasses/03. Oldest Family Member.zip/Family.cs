﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> people = new List<Person>();
       

        public void AddMember(Person member)
        {
            this.people.Add(member);
        }

        public Person GetOldestMember()
        {
            int oldestAge = -1;
            int oldestIndex = -1;

            for (int i = 0; i < people.Count; i++)
            {
                if (people[i].Age > oldestAge)
                {
                    oldestAge = people[i].Age;
                    oldestIndex = i;
                }
            }

            if (oldestIndex > -1)
            {
                return people[oldestIndex];
            }
            else
            {
                return null;
            }
        }
    }
}
