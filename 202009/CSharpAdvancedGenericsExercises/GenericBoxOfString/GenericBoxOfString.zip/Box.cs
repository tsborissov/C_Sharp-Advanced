﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<T>
    {
        private T data;

        public Box(T input)
        {
            this.data = input;
        }

        public override string ToString()
        {
            return $"{this.data.GetType()}: {this.data}";
        }
    }
}
