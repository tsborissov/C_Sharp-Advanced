﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ComparingObjects
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var people = new List<Person>();

            string input = string.Empty;

            while ((input = Console.ReadLine()) != "END")
            {
                string[] personDetails = input
                    .Split()
                    .ToArray();

                people.Add(new Person(personDetails));
            }

            int position = int.Parse(Console.ReadLine());
            position--;

            int countOfMatches = 0;
            int countOfNotEqual = 0;
            int totalNumberOfPeople = people.Count;

            foreach (var person in people)
            {
                if (person.CompareTo(people[position]) == 0)
                {
                    countOfMatches++;
                }
                else
                {
                    countOfNotEqual++;
                }
            }

            if (countOfMatches == 0 || countOfMatches == 1)
            {
                Console.WriteLine("No matches");
            }
            else
            {
                Console.WriteLine($"{countOfMatches} {countOfNotEqual} {totalNumberOfPeople}");
            }
        }
    }
}
